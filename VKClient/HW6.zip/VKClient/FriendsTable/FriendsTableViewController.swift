//
//  FriendsTableViewController.swift
//  VKClient
//
//  Created by Илья Лебедев on 27.05.2021.
//

import UIKit

class FriendsTableViewController: UITableViewController, UISearchResultsUpdating, UISearchBarDelegate {
    func updateSearchResults(for searchController: UISearchController) {
        
    }
    
     
    @IBOutlet weak var searchBar: UISearchBar!
    var selectedFriend: User?
    
    //эталонный массив с именами для сравнения при поиске
    var perfectArrayWithNames: [String] = []
    
    // массив с именами меняется (при поиске) и используется в таблице
    var namesListModifed: [String] = []
    
    var lettersOfNames: [String] = []
    
    let friendsTableViewCellReuse = "FriendsTableViewCell"
    let fromFriendsToPhotoSegue = "fromFriendsToPhoto"
    
    func arrayOfUserNames() {
        
        // удаляем все элементы эталонного массива с именами
        perfectArrayWithNames.removeAll()
        
        // получаем число элементов массива
        for item in 0...(DataStorage.shared.usersArray.count - 1) {
            
            // добавляем элементы в эталонный массив с именами
            perfectArrayWithNames.append(DataStorage.shared.usersArray[item].name!)
        }
        namesListModifed = perfectArrayWithNames
    }

    func sortNamesAlphabetically() {
        var lettersSet = Set<Character>()
        
        lettersOfNames = []
        
        for name in namesListModifed {
            lettersSet.insert(name[name.startIndex])
        }
        
        for letter in lettersSet.sorted() {
            lettersOfNames.append(String(letter))
        }
    }
    
    func nameFriend(_ indexPath: IndexPath) -> String {
        var namesRows = [String]()
        for name in namesListModifed.sorted(){
            if lettersOfNames[indexPath.section].contains(name.first!) {
                namesRows.append(name)
            }
        }
        return namesRows[indexPath.row]
        
    }
    
    func avatarFriend(_ indexPath: IndexPath) -> UIImage? {
        for friend in DataStorage.shared.usersArray {
            let nameRows = nameFriend(indexPath)
            if friend.name!.contains(nameRows) {
                return friend.avatar
            }
        }
        return nil
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.register(UINib(nibName: "FriendsTableViewCell", bundle: nil), forCellReuseIdentifier: friendsTableViewCellReuse)
        
        searchBar.delegate = self
        arrayOfUserNames()
        sortNamesAlphabetically()

    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        namesListModifed = searchText.isEmpty ? perfectArrayWithNames: perfectArrayWithNames.filter{(item: String) -> Bool in return item.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil}
        
        sortNamesAlphabetically()
        tableView.reloadData()
    }
    
    // отмена поиска (через кнопку Cancel)
    func searchBarTextDidBeginEditing(_ searchBar: UISearchBar) {
        self.searchBar.showsCancelButton = true // показыть кнопку Cancel
    }
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.showsCancelButton = false // скрыть кнопку Cancel
        searchBar.text = nil
        arrayOfUserNames() // возвращаем массив имен
        sortNamesAlphabetically()  // создаем заново массив заглавных букв для хедера
        tableView.reloadData() //обновить таблицу
        searchBar.resignFirstResponder() // скрыть клавиатуру
    }
    
    
    
    

    override func numberOfSections(in tableView: UITableView) -> Int {
  
        return lettersOfNames.count
    }
    
    // настройка хедера ячеек и добавление в него букв
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = UIView()
        // цвет и прозрачность хедера
        header.backgroundColor = UIColor.gray.withAlphaComponent(0.2)
        // координаты размещения букв
        let letter: UILabel = UILabel(frame: CGRect(x: 27, y: 5, width: 20, height: 20))
        // цвет и прозрачность букв
        letter.textColor = UIColor.blue.withAlphaComponent(1)
        letter.text = lettersOfNames[section]
        // размер и толщина букв
        letter.font = UIFont.systemFont(ofSize: 18, weight: UIFont.Weight.medium)
        header.addSubview(letter)
        
        return header
    }
    
    override func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return lettersOfNames
    }
    

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        var countOfRows = 0
        
        for name in namesListModifed {
            if lettersOfNames[section].contains(name.first!) {
                countOfRows += 1
            }
        }
        return countOfRows
        
//        return DataStorage.shared.usersArray.count
    }
  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: friendsTableViewCellReuse, for: indexPath) as? FriendsTableViewCell else {return UITableViewCell()}
       cell.configureWithUser(user: DataStorage.shared.usersArray[indexPath.row])
        cell.nameFriend.text = nameFriend(indexPath)
        cell.myImageView.image = avatarFriend(indexPath)
        return cell
    }
    
   
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super .prepare(for: segue, sender: sender)
        
        if segue.identifier == fromFriendsToPhotoSegue {
            
            guard let destination = segue.destination as? PhotoCollectionViewController else {return}
            destination.user = selectedFriend
            
            if let indexPath = tableView.indexPathForSelectedRow {
                
                destination.title = nameFriend(indexPath)
            }
        }
    }
 
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedFriend = DataStorage.shared.usersArray[indexPath.row]
        performSegue(withIdentifier: fromFriendsToPhotoSegue, sender: self)
    }



}
