//
//  ProfileTableViewCell.swift
//  VKClient
//
//  Created by Илья Лебедев on 02.06.2021.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {
    
    @IBOutlet weak var profileAvatarImage: UIImageView!
    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var photoCollectionProfile: UIImageView!

    
    var saveProfile: Profile?
    
    var saveImage: UIImage?
    
    func setup() {
        profileAvatarImage.layer.cornerRadius = 30
        
    }
    
    func clearCell() {
        profileAvatarImage.image = nil
        profileName.text = nil
        saveProfile = nil
    }
    
    func configure(avatar: UIImage?, name: String?, collection: UIImage?) {
        profileAvatarImage.image = avatar
        saveImage = avatar
        
        
        if let name = name {
            profileName.text = name
        }
        
        if let collection = collection {
            photoCollectionProfile.image = collection
        }
        
        
    }
    
    override func prepareForReuse() {
        clearCell()
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setup()
        clearCell()
       
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
