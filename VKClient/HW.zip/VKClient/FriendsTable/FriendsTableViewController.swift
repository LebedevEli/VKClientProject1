//
//  FriendsTableViewController.swift
//  VKClient
//
//  Created by Илья Лебедев on 27.05.2021.
//

import UIKit

class FriendsTableViewController: UITableViewController {
    
    let friendsTableViewCellReuse = "FriendsTableViewCell"
    let fromFriendsToPhotoSegue = "fromFriendsToPhoto"

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.register(UINib(nibName: "FriendsTableViewCell", bundle: nil), forCellReuseIdentifier: friendsTableViewCellReuse)

    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
  
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return DataStorage.shared.usersArray.count
    }

  
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: friendsTableViewCellReuse, for: indexPath) as? FriendsTableViewCell else {return UITableViewCell()}
        
        cell.configureWithUser(user: DataStorage.shared.usersArray[indexPath.row])
        


        return cell
    }
   
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == fromFriendsToPhotoSegue {
            guard let user = sender as? User,
                  let destination = segue.destination as? PhotoCollectionViewController else {return}
            destination.user = user
        }
    }
 
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) as? FriendsTableViewCell,
              let user = cell.saveUser
        else {return}
        
        performSegue(withIdentifier: fromFriendsToPhotoSegue, sender: user)
    }



}
