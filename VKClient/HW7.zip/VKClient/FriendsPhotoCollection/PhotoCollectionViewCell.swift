//
//  PhotoCollectionViewCell.swift
//  VKClient
//
//  Created by Илья Лебедев on 27.05.2021.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var photoImage: UIImageView!
    @IBOutlet weak var likeView: UIView!
//    @IBOutlet weak var heartImage: UIImageView!
    @IBOutlet weak var likeButton: LikeButton!
    @IBOutlet weak var commentButton: LikeButton!
    
//    func recognizerFunc() {
//        let recognizer = UITapGestureRecognizer(target: self, action: #selector(onTapLike))
//        recognizer.numberOfTapsRequired = 1
//        recognizer.numberOfTouchesRequired = 1
//        likeView.addGestureRecognizer(recognizer)
//    }
    
 
    
//    var likeStatus = false
//
//    @objc func onTapLike() {
//        if likeStatus {
//            heartImage.image = UIImage(systemName: "heart.fill")
//            likeLabel.text = "1"
//            likeStatus = false
//        }
//        else {
//            heartImage.image = UIImage(systemName: "heart")
//            likeLabel.text = "0"
//            likeStatus = true
//        }
//    }
    
    
    var savedImage: UIImage?
    
    func clearCell() {
        likeButton = nil
        commentButton = nil
        likeView = nil
        photoImage.image = nil
        savedImage = nil
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }
    override func prepareForReuse() {
        clearCell()
    }
    
    func configure(image: UIImage, like: UIImage?, comment: UIImage?) {
        photoImage.image = image
        savedImage = image
        
        if let comment = comment {
            commentButton.likeImage = comment
        }
        
        if let like = like {
            likeButton.likeImage = like
        }
    }

}
